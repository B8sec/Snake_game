package utk.Snakegame;

public class snake1 {
    public static void main(String args[]){
        new GameFrame();
    }
}
