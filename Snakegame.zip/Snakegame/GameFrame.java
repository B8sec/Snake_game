package utk.Snakegame;

import javax.swing.JFrame;
import java.awt.EventQueue;

public class GameFrame extends JFrame {
    GameFrame(){
        this.add(new Gamepanel());
        this.setTitle("Snake");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

    }
    
}
